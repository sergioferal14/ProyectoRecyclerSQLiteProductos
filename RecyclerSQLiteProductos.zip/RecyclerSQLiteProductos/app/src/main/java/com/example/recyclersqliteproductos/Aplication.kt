package com.example.recyclersqliteproductos

import android.app.Application
import android.content.Context
import com.example.recyclersqliteproductos.providers.db.MyDatabase

class Aplication: Application() {

    companion object{
        const val VERSION=2
        const val DB="Base_1"
        const val TABLA="productos"
        lateinit var contexto: Context
        lateinit var llave : MyDatabase

    }

    override fun onCreate() {
        super.onCreate()
        contexto=applicationContext
        llave= MyDatabase()
    }
}