package com.example.recyclersqliteproductos

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.recyclersqliteproductos.databinding.ActivityAddBinding
import com.example.recyclersqliteproductos.models.ProductoModel
import com.example.recyclersqliteproductos.providers.db.CrudProductos

class AddActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddBinding
    private var nombre = ""
    private var descripcion = ""
    private var precio = 0.0
    private var id = 1
    private var isUpdate = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAddBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recogerProducto()
        setListeners()

        if (isUpdate) {
            binding.etTitle2.text = "Editar Producto"
            binding.btnGuardar.text = "EDITAR"
        }
    }

    private fun recogerProducto() {
        val datos = intent.extras
        if (datos != null) {
            val p = datos.getSerializable("PRODUCTO") as ProductoModel
            isUpdate = true
            nombre = p.nombre
            descripcion = p.descripcion
            precio = p.precio
            id = p.id
            pintarDatos()
        }
    }

    private fun pintarDatos() {
        binding.etNombre.setText(nombre)
        binding.etDescripcion.setText(descripcion)
        binding.etPrecio.setText(precio.toString())
    }

    private fun setListeners() {
        binding.btnCancelar.setOnClickListener {
            finish()
        }

        binding.btnLimpiar.setOnClickListener {
            limpiar()
        }

        binding.btnGuardar.setOnClickListener {
            guardarProducto()
        }
    }

    private fun limpiar() {
        binding.etNombre.setText("")
        binding.etDescripcion.setText("")
        binding.etPrecio.setText("")
    }

    private fun guardarProducto() {
        if (datosCorrectos()) {
            val producto = ProductoModel(id, nombre, descripcion, precio)

            if (!isUpdate) {
                // Crear un nuevo producto
                if (CrudProductos().create(producto) != 1L) {
                    Toast.makeText(this, "Producto añadido correctamente", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    binding.etNombre.error = "El producto ya existe!!!"
                }
            } else {
                // Actualizar un producto existente
                if (CrudProductos().update(producto)) {
                    Toast.makeText(this, "Producto editado correctamente", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    binding.etNombre.error = "Error al editar el producto!!!"
                }
            }
        }
    }

    private fun datosCorrectos(): Boolean {
        nombre = binding.etNombre.text.toString().trim()
        descripcion = binding.etDescripcion.text.toString().trim()
        val precioString = binding.etPrecio.text.toString().trim()

        if (nombre.length < 3) {
            binding.etNombre.error = "El nombre debe tener al menos 3 caracteres"
            return false
        }

        if (descripcion.length < 5) {
            binding.etDescripcion.error = "La descripción debe tener al menos 5 caracteres"
            return false
        }

        if (precioString.isEmpty() || precioString.toDoubleOrNull() == null || precioString.toDouble() <= 0) {
            binding.etPrecio.error = "El precio debe ser un número mayor a 0"
            return false
        }

        precio = precioString.toDouble()
        if (precio > 9999.9) {
            binding.etPrecio.error = "El precio no puede ser mayor a 9999.9"
            return false
        }

        return true
    }
}