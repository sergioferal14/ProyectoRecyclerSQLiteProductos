package com.example.recyclersqliteproductos.providers.db

import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.recyclersqliteproductos.Aplication

class MyDatabase() :
    SQLiteOpenHelper(Aplication.contexto, Aplication.DB, null, Aplication.VERSION) {
    private val q = "CREATE TABLE ${Aplication.TABLA} (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "nombre TEXT UNIQUE NOT NULL CHECK(length(nombre) <= 40)," +
            "descripcion TEXT," +
            "precio REAL CHECK(precio <= 9999.99));"

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(q)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        if (newVersion > oldVersion) {
            val borrarTabla = "drop table ${Aplication.TABLA};"
            db?.execSQL(borrarTabla)
            onCreate(db)
        }
    }
}