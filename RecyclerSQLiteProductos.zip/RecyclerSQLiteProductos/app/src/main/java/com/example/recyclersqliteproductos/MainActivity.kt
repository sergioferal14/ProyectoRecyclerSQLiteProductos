package com.example.recyclersqliteproductos

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recyclersqliteproductos.adapters.ProductoAdapter
import com.example.recyclersqliteproductos.databinding.ActivityMainBinding
import com.example.recyclersqliteproductos.models.ProductoModel
import com.example.recyclersqliteproductos.providers.db.CrudProductos

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var listaProductos = mutableListOf<ProductoModel>()
    private lateinit var adapter: ProductoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setRecycler()
        setListeners()
        title = "Inventario de Productos"
    }

    private fun setRecycler() {
        // Configuración del RecyclerView
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        cargarProductos()
        adapter = ProductoAdapter(
            listaProductos,
            { position -> eliminarProducto(position) },
            { producto -> actualizarProducto(producto) }
        )
        binding.recyclerView.adapter = adapter
    }

    private fun cargarProductos() {
        // Leer productos desde la base de datos
        listaProductos = CrudProductos().read()
        if (listaProductos.isNotEmpty()) {
            binding.ivProductos.visibility = View.INVISIBLE
        } else {
            binding.ivProductos.visibility = View.VISIBLE
        }
    }

    private fun eliminarProducto(position: Int) {
        val producto = listaProductos[position]
        val id = producto.id
        val nombre = producto.nombre

        AlertDialog.Builder(this)
            .setTitle("Eliminar Producto")
            .setMessage("¿Seguro que deseas eliminar el producto \"$nombre\"?")
            .setNegativeButton("CANCELAR") { dialog, _ ->
                dialog.dismiss()
            }
            .setPositiveButton("ACEPTAR") { _, _ ->
                if (CrudProductos().borrar(id)) {
                    listaProductos.removeAt(position)
                    adapter.notifyItemRemoved(position)
                    Toast.makeText(this, "Producto eliminado", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Error al eliminar el producto", Toast.LENGTH_SHORT).show()
                }
            }
            .create()
            .show()
    }

    private fun actualizarProducto(producto: ProductoModel) {
        val intent = Intent(this, AddActivity::class.java).apply {
            putExtra("PRODUCTO", producto)
        }
        startActivity(intent)
    }

    private fun setListeners() {
        binding.fabAdd.setOnClickListener {
            // Abrir AddActivity para agregar un nuevo producto
            startActivity(Intent(this, AddActivity::class.java))
        }
    }

    override fun onRestart() {
        super.onRestart()
        setRecycler()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_principal, menu)
        return super.onCreateOptionsMenu(menu)
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.item_borrar_todo -> {
                confirmarBorradoTodo()
            }

            R.id.item_salir -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }


    private fun confirmarBorradoTodo() {
        AlertDialog.Builder(this)
            .setTitle("Borrar Todo")
            .setMessage("¿Estás seguro de que deseas eliminar todos los productos?")
            .setNegativeButton("CANCELAR") { dialog, _ ->
                dialog.dismiss()
            }
            .setPositiveButton("ACEPTAR") { dialog, _ ->
                CrudProductos().borrarTodo()
                setRecycler()
            }
            .create()
            .show()
    }
}