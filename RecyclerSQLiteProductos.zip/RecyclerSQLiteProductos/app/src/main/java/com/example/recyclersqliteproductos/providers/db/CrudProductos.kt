package com.example.recyclersqliteproductos.providers.db

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import com.example.recyclersqliteproductos.Aplication
import com.example.recyclersqliteproductos.models.ProductoModel

class CrudProductos {
    fun create(p: ProductoModel): Long {
        val con = Aplication.llave.writableDatabase // Abrimos la base de datos en modo escritura

        return try {
            con.insertWithOnConflict(
                Aplication.TABLA,
                null,
                p.toContentValues(),
                SQLiteDatabase.CONFLICT_IGNORE
            )
        } catch (ex: Exception) {
            ex.printStackTrace()
            -1L
        } finally {
            con.close()
        }
    }

    fun read(): MutableList<ProductoModel> {
        val lista = mutableListOf<ProductoModel>()
        val con = Aplication.llave.readableDatabase

        try {
            val cursor = con.query(
                Aplication.TABLA,
                arrayOf("id", "nombre", "descripcion", "precio"),
                null,
                null,
                null,
                null,
                null
            )
            while (cursor.moveToNext()) {
                val producto = ProductoModel(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getDouble(3)
                )
                lista.add(producto)
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
        } finally {
            con.close()
        }

        return lista
    }

    fun borrar(id: Int): Boolean {
        val con = Aplication.llave.writableDatabase
        val productoBorrado = con.delete(Aplication.TABLA, "id=?", arrayOf(id.toString()))
        con.close()
        return productoBorrado > 0
    }

    fun update(p: ProductoModel): Boolean {
        val con = Aplication.llave.writableDatabase
        val values = p.toContentValues()
        var filasAfectadas = 0

        val q = "SELECT id FROM ${Aplication.TABLA} WHERE nombre=? AND id <> ?"
        val cursor = con.rawQuery(q, arrayOf(p.nombre, p.id.toString()))
        val existeNombre = cursor.moveToFirst()
        cursor.close()

        if (!existeNombre) {
            filasAfectadas = con.update(Aplication.TABLA, values, "id=?", arrayOf(p.id.toString()))
        }
        con.close()
        return filasAfectadas > 0
    }

    fun borrarTodo() {
        val con = Aplication.llave.writableDatabase
        con.execSQL("DELETE FROM ${Aplication.TABLA}")
        con.close()
    }

    private fun ProductoModel.toContentValues(): ContentValues {
        return ContentValues().apply {
            put("nombre", nombre)
            put("descripcion", descripcion)
            put("precio", precio)
        }
    }
}