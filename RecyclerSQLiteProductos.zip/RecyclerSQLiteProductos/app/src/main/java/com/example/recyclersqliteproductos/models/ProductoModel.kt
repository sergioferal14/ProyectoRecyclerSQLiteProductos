package com.example.recyclersqliteproductos.models

import java.io.Serializable

data class ProductoModel (
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val precio: Double
    ): Serializable