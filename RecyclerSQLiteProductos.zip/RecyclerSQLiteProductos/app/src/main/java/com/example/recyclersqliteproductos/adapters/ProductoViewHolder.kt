package com.example.recyclersqliteproductos.adapters

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclersqliteproductos.databinding.ProductoLayoutBinding
import com.example.recyclersqliteproductos.models.ProductoModel

class ProductoViewHolder(v: View) : RecyclerView.ViewHolder(v) {
    val binding = ProductoLayoutBinding.bind(v)

    fun render(
        p: ProductoModel,
        borrarProducto: (Int) -> Unit,
        update: (ProductoModel) -> Unit
    ) {
        binding.tvNombre.text = p.nombre
        binding.tvDescripcion.text = p.descripcion
        binding.tvPrecio.text = "${p.precio}€"

        binding.btnBorrar.setOnClickListener {
            borrarProducto(adapterPosition)
        }
        binding.btnUpdate.setOnClickListener {
            update(p)
        }
    }
}